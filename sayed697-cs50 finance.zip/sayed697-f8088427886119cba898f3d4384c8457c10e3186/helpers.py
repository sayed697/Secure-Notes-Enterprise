import os
import requests

from flask import redirect, render_template, session
from functools import wraps


def apology(message, code=400):
    """Render message as an apology to user."""

    def escape(s):
        """
        Escape special characters.
        https://github.com
        """
        for old, new in [
            ("-", "--"),
            ("_", "__"),
            ("?", "~q"),
            ("%", "~p"),
            ("#", "~h"),
            ("/", "~s"),
            ('"', "''"),
        ]:
            s = s.replace(old, new)
        return s

    return render_template("apology.html", top=code, bottom=escape(message)), code


def login_required(f):
    """
    Decorate routes to require login.
    https://palletsprojects.com
    """

    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)

    return decorated_function


def lookup(symbol):
    """Look up quote for symbol."""
    # Prepare API request
    symbol = symbol.upper()

    # URL for CS50's IEX Cloud API simulator
    url = f"https://cs50.io{symbol}"

    # Query API
    try:
        response = requests.get(url)
        response.raise_for_status()
        quote_data = response.json()
        return {
            "name": quote_data["name"],
            "price": float(quote_data["price"]),
            "symbol": quote_data["symbol"]
        }
    except (requests.RequestException, ValueError, KeyError, IndexError):
        return None


def usd(value):
    """Format value as USD."""
    return f"${value:,.2f}"
