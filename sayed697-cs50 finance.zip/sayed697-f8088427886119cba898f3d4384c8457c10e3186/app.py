import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""
    user_id = session["user_id"]

    # جلب جميع الأسهم التي يمتلكها المستخدم حالياً
    stocks = db.execute(
        "SELECT symbol, SUM(shares) as total_shares FROM transactions WHERE user_id = ? GROUP BY symbol HAVING total_shares > 0",
        user_id
    )

    # جلب النقد المتبقي في محفظة المستخدم
    cash_row = db.execute("SELECT cash FROM users WHERE id = ?", user_id)
    cash = cash_row[0]["cash"]

    total_value = cash
    portfolio = []

    for stock in stocks:
        quote_data = lookup(stock["symbol"])
        if quote_data:
            current_price = quote_data["price"]
            stock_total = current_price * stock["total_shares"]
            total_value += stock_total
            portfolio.append({
                "symbol": stock["symbol"],
                "name": quote_data["name"],
                "shares": stock["total_shares"],
                "price": usd(current_price),
                "total": usd(stock_total)
            })

    return render_template("index.html", portfolio=portfolio, cash=usd(cash), total=usd(total_value))


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""
    if request.method == "POST":
        symbol = request.form.get("symbol")
        shares_input = request.form.get("shares")

        if not symbol:
            return apology("must provide symbol", 400)

        quote_data = lookup(symbol)
        if not quote_data:
            return apology("invalid symbol", 400)

        # التحقق من أن عدد الأسهم المدخل هو رقم صحيح موجب
        try:
            shares = int(shares_input)
            if shares <= 0:
                return apology("shares must be a positive integer", 400)
        except (ValueError, TypeError):
            return apology("shares must be a positive integer", 400)

        user_id = session["user_id"]
        cash_row = db.execute("SELECT cash FROM users WHERE id = ?", user_id)
        user_cash = cash_row[0]["cash"]

        cost = quote_data["price"] * shares
        if user_cash < cost:
            return apology("can't afford", 400)

        # تحديث المحفظة النقدية وتسجيل عملية الشراء
        db.execute("UPDATE users SET cash = cash - ? WHERE id = ?", cost, user_id)
        db.execute(
            "INSERT INTO transactions (user_id, symbol, shares, price) VALUES (?, ?, ?, ?)",
            user_id, quote_data["symbol"], shares, quote_data["price"]
        )

        flash("Bought!")
        return redirect("/")
    else:
        return render_template("buy.html")


@app.route("/history")
@login_required
def history():
    """Show history of transactions"""
    user_id = session["user_id"]
    transactions = db.execute(
        "SELECT symbol, shares, price, timestamp FROM transactions WHERE user_id = ? ORDER BY timestamp DESC",
        user_id
    )
    for t in transactions:
        t["price"] = usd(t["price"])
    return render_template("history.html", transactions=transactions)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""
    session.clear()

    if request.method == "POST":
        if not request.form.get("username"):
            return apology("must provide username", 403)
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        rows = db.execute(
            "SELECT * FROM users WHERE username = ?", request.form.get("username")
        )

        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("invalid username and/or password", 403)

        session["user_id"] = rows[0]["id"]
        return redirect("/")
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""
    session.clear()
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    if request.method == "POST":
        symbol = request.form.get("symbol")
        if not symbol:
            return apology("must provide symbol", 400)

        quote_data = lookup(symbol)
        if not quote_data:
            return apology("invalid symbol", 400)

        return render_template("quoted.html", name=quote_data["name"], price=usd(quote_data["price"]), symbol=quote_data["symbol"])
    else:
        return render_template("quote.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        confirmation = request.form.get("confirmation")

        if not username:
            return apology("must provide username", 400)
        elif not password or not confirmation:
            return apology("must provide password", 400)
        elif password != confirmation:
            return apology("passwords do not match", 400)

        try:
            hash_password = generate_password_hash(password)
            db.execute("INSERT INTO users (username, hash) VALUES (?, ?)", username, hash_password)
            return redirect("/login")
        except:
            return apology("username already exists", 400)
    else:
        return render_template("register.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""
    user_id = session["user_id"]

    if request.method == "POST":
        symbol = request.form.get("symbol")
        shares_input = request.form.get("shares")

        if not symbol:
            return apology("must provide symbol", 400)

        try:
            shares = int(shares_input)
            if shares <= 0:
                return apology("shares must be a positive integer", 400)
        except (ValueError, TypeError):
            return apology("shares must be a positive integer", 400)

        # التحقق من كمية الأسهم التي يمتلكها المستخدم بالفعل لبيعها
        stock_row = db.execute(
            "SELECT SUM(shares) as total_shares FROM transactions WHERE user_id = ? AND symbol = ? GROUP BY symbol",
            user_id, symbol.upper()
        )

        if not stock_row or stock_row[0]["total_shares"] < shares:
            return apology("not enough shares", 400)

        quote_data = lookup(symbol)
        revenue = quote_data["price"] * shares

        # تسجيل عملية البيع بإشارة سالبة وتحديث النقد
        db.execute("UPDATE users SET cash = cash + ? WHERE id = ?", revenue, user_id)
        db.execute(
            "INSERT INTO transactions (user_id, symbol, shares, price) VALUES (?, ?, ?, ?)",
            user_id, quote_data["symbol"], -shares, quote_data["price"]
        )

        flash("Sold!")
        return redirect("/")
    else:
        stocks = db.execute(
            "SELECT symbol FROM transactions WHERE user_id = ? GROUP BY symbol HAVING SUM(shares) > 0",
            user_id
        )
        return render_template("sell.html", stocks=stocks)



