import os
from flask import redirect, render_template, session
from functools import wraps

def login_required(f):
    """
    تعطيل الوصول للمسارات المحمية إلا بعد تسجيل الدخول
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated_function
