# Personal Diary & Notes Web Application

### **Project Video URL:** [https://youtube.com/shorts/xJRz-sExmYA?si=UqWggQSRXFV4IJg7]

#### **Description:**
This web application is a fully personalized and highly secure **Digital Diary and Notes Manager** created to empower users to digitally log, archive, track, and look back at their personal daily thoughts, tasks, and historical notes. Built efficiently using **Python, Flask, and SQLite**, the application places a massive emphasis on layout simplicity, responsive interactions, and thorough backend validation routines.

The core motivation behind this project is to fix a common issue in note-taking apps: privacy. In this system, user isolation is fully guaranteed. Through custom session middleware and relational database structures, every user exists in their own localized space. A user can only view, create, edit, or delete notes that are explicitly tied to their personal primary key in the SQLite instance, rendering data completely inaccessible to malicious entities or unauthorized concurrent traffic sessions.

---

#### **Core Features Explained:**
*   **Secure Authentication Architecture:** Includes full-fledged registration and identity verification procedures. Passwords are never stored in raw text; instead, they are converted into dynamic cryptographic strings using SHA-256 password hashing protocols via `werkzeug.security`.
*   **Dynamic Data Query Dashboard:** The centralized homepage features an active querying system that targets the logged-in individual's index. It dynamically pulls records and processes them chronologically, meaning that the newest journal entries always automatically stack on top.
*   **Asynchronous-Ready Input Forms:** The interface for generating fresh journal entries provides isolated inputs for both header summaries (titles) and multiline blocks (the main body content).
*   **Automated Schema Generation:** To reduce setup steps, the backend automatically scans the local SQLite directory when launching the server. If `diary.db` is missing its tables, it fires native DDL statements to instantly migrate the structural setup for `users` and `notes`.

---

#### **Detailed File Breakdown & Technical Architecture:**

1.  **`app.py`**: Acting as the foundational command center and central controller for the entire architecture, this file dictates every single HTTP request and server-side response. It maps out application routes (`/`, `/login`, `/register`, `/add`, `/logout`), handles input evaluation to prevent missing data errors, configures filesystem-based session management, and coordinates raw query bindings with the database engine.
2.  **`helpers.py`**: This script contains vital utility functions. Most notably, it implements the `@login_required` decorator method, which wraps around secure app routing nodes. If an unauthenticated client attempts to force their way into the root dashboard or the addition portal via url-manipulation, this middleware intercepts the request and instantly drops them back at the portal gates.
3.  **`diary.db`**: A self-contained, light, relational SQLite storage core. It maintains explicit relational mapping through two tables linked via a primary-to-foreign key paradigm (`users.id` matched to `notes.user_id`), ensuring data integrity is never broken across operations.
4.  **`templates/layout.html`**: Serving as the global graphical template skeleton, this file establishes the fundamental markup framework, global responsive metadata scales, and embeds a dynamic, reactive Bootstrap 5 navigation toolbar that shifts links based on whether a user is logged in or out.
5.  **`templates/index.html`**: A tailored UI layout utilizing modern layout components to display structural user notes. If a new user logs in and has no data, it displays a responsive call-to-action placeholder.
6.  **`templates/add.html`**: A strict modal form specifically engineered to capture text blocks from user endpoints and stream them smoothly down to active POST routing parameters.
7.  **`templates/login.html` & `register.html`**: Simple user entry points equipped with auto-focus constraints, secure password hidden forms, and explicit method mapping to safeguard credential delivery.

---

#### **Design Decisions & Project Evolution:**
Choosing to scale down from a high-frequency financial tracker into an intimate digital note archive allowed for deep optimization regarding database handling. Instead of executing multiple complex aggregations for stock calculations, this architecture refines CRUD practices, ensuring rapid query execution times. The interface style deliberately avoids heavy assets to focus strictly on text clarity, fluid screen transitions, and multi-device usability.
