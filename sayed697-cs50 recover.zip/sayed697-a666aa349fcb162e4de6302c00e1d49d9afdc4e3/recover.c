#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

// تعريف نوع بيانات بايت (8 بت) لقراءة البيانات
typedef uint8_t BYTE;

// حجم البلوك الثابت في بطاقات الذاكرة (512 بايت)
#define BLOCK_SIZE 512

int main(int argc, char *argv[])
{
    // 1. التأكد من إدخال اسم ملف الذاكرة في سطر الأوامر
    if (argc != 2)
    {
        printf("Usage: ./recover CARD.raw\n");
        return 1;
    }

    // 2. فتح ملف الذاكرة للقراءة
    FILE *raw_file = fopen(argv[1], "r");
    if (raw_file == NULL)
    {
        printf("Could not open file.\n");
        return 1;
    }

    BYTE buffer[BLOCK_SIZE];
    FILE *img = NULL;
    char filename[8]; // لتخزين اسم الصورة المسترجعة مثل "000.jpg"
    int count = 0;    // عداد الصور المسترجعة

    // 3. قراءة بطاقة الذاكرة بلوك تلو الآخر (كل بلوك 512 بايت)
    while (fread(buffer, 1, BLOCK_SIZE, raw_file) == BLOCK_SIZE)
    {
        // التحقق مما إذا كانت بداية البلوك الحالي تمثل توقيع صورة JPEG
        if (buffer[0] == 0xff && buffer[1] == 0xd8 && buffer[2] == 0xff && (buffer[3] & 0xf0) == 0xe0)
        {
            // إذا كان هناك ملف صورة مفتوح مسبقاً، نقوم بإغلاقه لحفظه
            if (img != NULL)
            {
                fclose(img);
            }

            // توليد اسم للملف الجديد بالترتيب (مثل: 000.jpg, 001.jpg)
            sprintf(filename, "%03i.jpg", count);

            // فتح ملف جديد للكتابة فيه
            img = fopen(filename, "w");
            count++;
        }

        // إذا تم العثور على صورة وبدأنا في استخراجها، نستمر بكتابة البلوكات بداخلها
        if (img != NULL)
        {
            fwrite(buffer, 1, BLOCK_SIZE, img);
        }
    }

    // 4. إغلاق كافة الملفات المفتوحة لتنظيف الذاكرة
    if (img != NULL)
    {
        fclose(img);
    }
    fclose(raw_file);

    return 0;
}
